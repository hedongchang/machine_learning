HW1 is for homework 1
It should not be graded.:)